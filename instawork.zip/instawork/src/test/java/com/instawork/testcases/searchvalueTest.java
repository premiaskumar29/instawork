package com.instawork.testcases;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.instawork.base.Testbase;
import com.instawork.pages.googlePage;

public class searchvalueTest extends Testbase{
	
	googlePage googlepage;
	String text="www.instawork.com";
	
	public searchvalueTest()
	{
		super();
	}
	
	@Parameters({ "browser" })
	@BeforeTest
	public void setup(String browser)
	{
		read(browser);
	    googlepage=new googlePage();
	}
	
	@AfterTest
	public void closebrowser()
	{
		driver.quit();
	}
	
	@Test
	public void searchtext()
	{
		googlepage.enterText(text);
		googlepage.clickOnSearcBtn();
		googlepage.verifyText(text);
	}
	
	

}

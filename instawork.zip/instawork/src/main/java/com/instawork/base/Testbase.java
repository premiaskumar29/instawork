package com.instawork.base;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.instawork.utility.utility;

public class Testbase {

	public static	WebDriver driver;
	public static Properties property;



	public Testbase() {

		try {
			property=new Properties();
			FileInputStream fis=new FileInputStream(System.getProperty("user.dir")+"/src/main/java/com/instawork/config/config.properties");
			property.load(fis);
		}catch (Exception e) {
			e.printStackTrace();
		}
	}


	public static void read(String browsername) {
		String url=property.getProperty("url"); 

		if(browsername.equalsIgnoreCase("chrome")) {
			System.getProperty("webdriver.chrome.driver","/usr/bin/chromedriver");
			driver=new ChromeDriver(); 

		}else if(browsername.equalsIgnoreCase("firefox"))
		{ 
			System.setProperty("webdriver.gecko.driver", "/usr/bin/geckodriver");
			driver=new FirefoxDriver();
		}

		driver.manage().window().maximize();
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);

		//Launch Url google.com 
		driver.get(url);
		utility.waitForPageLoad();
	}

}


package com.instawork.utility;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.instawork.base.Testbase;

public class utility extends Testbase{

	

		
		 public  static void waitForPageLoad() {

		        ExpectedCondition<Boolean> expectation = new ExpectedCondition<Boolean>() {
		            public Boolean apply(WebDriver driver) {
		                return ((JavascriptExecutor) driver).executeScript("return document.readyState").equals("complete");
		            }
		        };

		        WebDriverWait wait = new WebDriverWait(driver, 30);
		        try {
		            wait.until(expectation);
		        } catch (Exception error) {
		            Assert.assertFalse(true, "Timeout waiting for Page Load Request to complete.");
		        }

		    }

	}

